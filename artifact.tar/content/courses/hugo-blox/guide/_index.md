---
title: Guide
weight: 2
sidebar:
  open: true
---

{{< cards >}}
  {{< card url="formatting" title="Formatting" icon="document-duplicate" >}}
  {{< card url="project-structure" title="Project Structure" icon="document-duplicate" >}}
  {{< card url="configuration" title="Configuration" icon="adjustments-vertical" >}}
{{< /cards >}}
